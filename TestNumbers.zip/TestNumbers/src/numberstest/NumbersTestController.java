/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numberstest;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author Wakiti
 */
public class NumbersTestController implements Initializable {

    @FXML
    private TextField Number1TextField;
    @FXML
    private TextField Number2TextField;
    @FXML
    private TextField Number3TextField;
    @FXML
    private Button RunButton;
    @FXML
    private Text AdditionAnswer;
    @FXML
    private Text MultiplicationAnswer;
    @FXML
    private Text SubtractionAnswer1;
    @FXML
    private Text SubtractionAnswer2;
    @FXML
    private Text DivisionAnswer1;
    @FXML
    private Text DivisionAnswer2;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    public void RunNumbers(ActionEvent event) {
        String Text1 = Number1TextField.getText();
        int Number1 = Integer.parseInt(Text1);
        String Text2 = Number2TextField.getText();
        int Number2 = Integer.parseInt(Text2); 
        String Text3 = Number3TextField.getText();
        int Number3 = Integer.parseInt(Text3);   
        boolean b1 = true;
        boolean b2 = false;
        
      if(Number1+Number2==Number3){AdditionAnswer.setText("Adding Number1+Number2 Works");
      }
      else{
          AdditionAnswer.setText("None");}
          
      
      if(Number1*Number2==Number3){MultiplicationAnswer.setText("Multiplying Number1*Number2 Works");
      }
          else{
          MultiplicationAnswer.setText("None");}
          
      if(Number1-Number2==Number3){SubtractionAnswer1.setText("Subtracting Number1-Number2 Works");
      }
          else{
          SubtractionAnswer1.setText("None");}
          
      
      if(Number2-Number1==Number3){SubtractionAnswer2.setText("Subtracting Number2-Number1 Works");
      }
          else{
          SubtractionAnswer2.setText("None");}
          
      
      if(Number1/Number2==Number3){DivisionAnswer1.setText("Dividing Number1/Number2 Works");
      }
          else{
          DivisionAnswer1.setText("None");}
          
      
      if(Number2/Number1==Number3){DivisionAnswer2.setText("Dividing Number2/Number1 Works");
      }
          else{
          DivisionAnswer2.setText("None");}
      
          }
      
    }

    

  
    

